<script>
function myFunction() {
  document.getElementById("logDrop").classList.toggle("show");
}

window.onclick = function(event) {
if (!event.target.matches('.dropbtn')) {

  var dropdowns = document.getElementsByClassName("dropdown-content");

}
}

</script>
